# Usage
You can use Theta Tools in 2 Easy Steps!

1. Browse the component library (In the documentation) for the component you'd like to add
2. Click the 'Implement' button