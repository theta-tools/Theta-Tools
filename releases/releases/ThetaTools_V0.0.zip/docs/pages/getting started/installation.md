# Installation
You can install Theta Tools in 2 Easy Steps!
1. Download the latest release from the [website](https://theta-tools.github.io/releases)
2. Extract the `.zip` file into the root folder of your project