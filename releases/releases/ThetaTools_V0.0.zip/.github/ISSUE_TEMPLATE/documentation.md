---
name: Documentation
about: For adding, removing, and updating the Documentation
title: "[Docs] - TITLE HERE"
labels: Documentation
assignees: ''

---

## About the Issue
**Category**
- [ ] Addition
- [ ] Modification
- [ ] Removal

## Content of the Issue
**Section**
Which section of the documentation does this relate to?

**Page Title**
What's the title of the page?

**Details**
What should the page say?
