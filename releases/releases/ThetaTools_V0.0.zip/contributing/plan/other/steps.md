# Other Contributions
[Back](/contributing/plan)

1. [Create an issue](https://github.com/theta-tools/theta-tools.github.io/issues/new/choose) for your contribution
2. Fork the [repository](https://github.com/theta-tools/theta-tools.github.io/fork)
3. Make your changes
6. Submit your changes via a pull request
7. Wait for a moderator to approve your changes